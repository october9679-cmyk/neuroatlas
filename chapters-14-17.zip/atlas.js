'use strict';

const chapterStyle = {
  14:['局部麻醉药','syringe','#81e9d7'],
  15:['镇静催眠与促觉醒','moon','#c0a7fa'],
  16:['抗癫痫与抗惊厥药','pulse','#92baff'],
  17:['神经退行性疾病药','neuron','#9bdcca'],
  18:['抗精神失常药','mind','#e5a6d4'],
  19:['中枢镇痛药','capsule','#ffab9f'],
  20:['解热镇痛抗炎药','flame','#f3ca88']
};
const chapters = new Map();
const topics = new Map();
const searchIndex = [];
const $ = selector => document.querySelector(selector);
const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const asset = path => window.ATLAS_ASSETS?.[path] || path;
const mark = (name,size=22) => `<span class="glyph">${icon(name,size)}</span>`;
const chapterPath = (c,b) => `/map/${c.id}${b ? '/'+b.n : ''}`;
const sources = {
  '卡马西平':['第 22 页与本章小结对失神发作的表述不一致。卡马西平可能加重失神发作，典型失神的代表药是乙琥胺。','NICE NG217 · 第 5.3 节','https://www.nice.org.uk/guidance/ng217/chapter/treating-epileptic-seizures-in-children-young-people-and-adults#absence-seizures'],
  '曲马多的双重机制':['第 45 页对呼吸影响的表述过于绝对。曲马多仍有严重呼吸抑制风险。','DailyMed · 曲马多药品说明书','https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=42de8c3a-0441-5d46-e063-6294a90a2079'],
  '仑卡奈单抗':['仑卡奈单抗用于有淀粉样蛋白病理证据的阿尔茨海默病早期患者。学习疗效时也要联系淀粉样蛋白相关影像异常（ARIA）风险。','FDA · 仑卡奈单抗说明书','https://www.accessdata.fda.gov/drugsatfda_docs/label/2024/761269s008lbl.pdf'],
  '胆碱能靶点与 Cobenfy':['复方含两种成分。Xanomeline 为毒蕈碱型受体激动药，trospium 为拮抗药，主要在外周发挥作用。','FDA · Cobenfy 药品资料','https://www.fda.gov/drugs/drug-trials-snapshots/drug-trials-snapshot-cobenfy']
};
function norm(value) {
  return String(value).normalize('NFKC').toLowerCase()
    .replace(/[䓬卓]/g,'卓').replace(/[μµ]/g,'mu').replace(/α/g,'alpha').replace(/β/g,'beta')
    .replace(/[δ]/g,'delta').replace(/κ/g,'kappa').replace(/[\s·_\-−–—.,，。、（）()[\]⁺＋+]/g,'');
}
for (const c of CURRICULUM) {
  [c.short,c.icon,c.color]=chapterStyle[c.id];
  c.size=0;
  chapters.set(c.id,c);
  searchIndex.push({kind:'chapter',c,title:c.title,text:norm(c.short+' '+c.title+' 第'+c.id+'章 '+c.summary)});
  for (const [bi,b] of c.branches.entries()) {
    b.n=bi+1;
    searchIndex.push({kind:'branch',c,b,title:b.title,text:norm(b.title+' '+b.summary)});
    for (const [ti,t] of b.topics.entries()) {
      t.id=`${c.id}.${b.n}.${ti+1}`;
      const entry={kind:'topic',c,b,t,title:t.title,alias:norm(t.aliases.join(' ')),text:norm([t.title,t.lead,...t.aliases,...t.points.flat()].join(' '))};
      topics.set(t.id,entry);
      searchIndex.push(entry);
      c.size++;
    }
  }
}
const numberOfPages=CURRICULUM.reduce((s,c)=>s+c.pageCount,0);
const storageKey='neuroatlas.study.v1';
function readStudy() {
  let raw={};
  try {raw=JSON.parse(localStorage.getItem(storageKey)||'{}')||{};} catch {}
  const read=k=>new Set((Array.isArray(raw[k])?raw[k]:[]).filter(id=>topics.has(id)));
  return {saved:read('saved'),done:read('done')};
}
let study=readStudy(), focusedChapter=14, currentBase='', dialogType='', dialogKey='', dialogTrigger=null;
const cameras=new Map(),positions=new Map();
let observer=null, graphCamera=null, noticeTimer, searchValue='', slideZoom=false;
const main=$('#main'), dialog=$('#study-dialog');
if ('scrollRestoration' in history) history.scrollRestoration='manual';

function readRoute() {
  const [path,query='']=(location.hash.slice(1)||'/map').split('?');
  const [,name,ci,bi]=path.split('/');
  const view=['map','chapters','saved'].includes(name)?name:'map';
  const c=view==='map'?chapters.get(Number(ci)):null;
  const b=c?.branches[Number(bi)-1];
  const base=c?chapterPath(c,b):'/'+view;
  const params=new URLSearchParams(query);
  return {view,c,b,base,params};
}
function goto(hash,replace=false) {
  const next=hash.startsWith('#')?hash:'#'+hash;
  if (next===location.hash || (!location.hash && next==='#/map')) {render();return;}
  const previous=location.hash||'#/map';
  if (replace) history.replaceState(history.state,'',next);
  else history.pushState({from:previous},'',next);
  render();
}
function hashWith(base,values={}) {
  const q=new URLSearchParams(values).toString();
  return '#'+base+(q?'?'+q:'');
}
function openLearningLayer(values,replace=false) {
  const dest=hashWith(readRoute().base,values);
  if(!replace && history.state?.from===dest)history.back();else goto(dest,replace);
}
function openTopic(key,replace=false){openLearningLayer({topic:key},replace);}
function goSource(cid,page,replace=false) {
  const {base,params}=readRoute(), c=chapters.get(Number(cid));
  if (!c) return;
  const values={};
  const key=params.get('topic');
  if (topics.has(key)) values.topic=key;
  values.source=c.id; values.page=Math.max(1,Math.min(c.pageCount,Math.round(Number(page))||1));
  goto(hashWith(base,values),replace);
}
function closeLayer() {
  const {base,params}=readRoute();
  const target=params.has('source')&&topics.has(params.get('topic'))?hashWith(base,{topic:params.get('topic')}):'#'+base;
  const previous=history.state?.from;
  if (previous && previous!==location.hash && previous.split('?')[0]==='#'+base) history.back();
  else goto(target,true);
}
function announce(message) {
  const el=$('#notice');el.textContent=message;el.classList.add('visible');
  clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>el.classList.remove('visible'),1900);
}
function progress() {
  const pct=Math.round(100*study.done.size/topics.size);
  return `<div class="progress-ring"><svg viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="15" fill="none" stroke="#c4e8ec29" stroke-width="2.5"/><circle cx="18" cy="18" r="15" fill="none" stroke="#95ecd8" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="${pct*.9425} 94.25"/></svg><b>${pct}%</b></div><span><strong>学习进度</strong><small>已掌握 ${study.done.size} / ${topics.size} 个知识点</small></span>`;
}
function intro(title,description) {
  return `<section class="intro"><div><div class="eyebrow"><span>药理学</span><span class="slash">/</span><span>第 14–20 章</span></div><h1>${esc(title)}</h1><p>${esc(description)}</p></div><div class="progress-pill optical" id="progress" aria-label="本浏览器的学习进度">${progress()}</div></section>`;
}
const comparisons=[
  {id:'sodium',title:'钠通道与高频放电',caption:'局麻药与苯妥英钠',symbol:'pulse',color:'#86e3d9',lead:'两类药都能影响电压门控钠通道。沿着“在哪条神经起作用”这条线索，可以区分局部麻醉与抗癫痫作用。',pairs:[
    ['14.1.2','在外周神经，局麻药进入细胞后阻滞钠通道，使动作电位难以继续传导，局部感觉随之减弱。'],
    ['16.2.1','在中枢异常放电的神经元，苯妥英钠延长钠通道的失活状态，限制高频、重复放电。']]},
  {id:'gaba',title:'GABA 与中枢抑制',caption:'从镇静催眠到抗惊厥',symbol:'moon',color:'#c2aaff',lead:'苯二氮䓬类增强 GABA 的抑制效应。把相同的受体机制放回不同神经环路，就能串起镇静与抗惊厥。',pairs:[
    ['15.2.1','在 GABA 存在时，苯二氮䓬类增加 GABA-A 受体氯通道的开放频率，使神经元较难兴奋。'],
    ['16.3.2','增强抑制性传递也有助于限制异常放电。第 16 章用地西泮和氯硝西泮说明这一抗发作作用。']]},
  {id:'dopamine',title:'多巴胺与运动调节',caption:'帕金森病与锥体外系反应',symbol:'neuron',color:'#b3dec9',lead:'黑质–纹状体通路把两章联系起来。同样是运动迟缓和肌强直，需要辨认多巴胺信号减弱的原因。',pairs:[
    ['17.1.1','帕金森病中，多巴胺能神经元退变，纹状体多巴胺调节减弱，胆碱能作用相对占优势。'],
    ['18.2.4','某些抗精神病药阻断黑质–纹状体通路的 D₂ 受体，可出现药源性帕金森综合征。']]},
  {id:'pain',title:'两条镇痛通路',caption:'阿片受体与前列腺素',symbol:'capsule',color:'#f6b3a6',lead:'镇痛是共同的结果。把疼痛信号分为外周敏化和中枢传递两个环节，就能看见两类药的作用位置。',pairs:[
    ['19.2.2','吗啡通过阿片受体调节中枢痛觉传递，同时影响疼痛带来的情绪体验。'],
    ['20.1.3','解热镇痛抗炎药抑制环氧合酶，减少前列腺素生成，减轻炎症部位痛觉感受器的敏化。']]},
  {id:'temperature',title:'体温调节与解热',caption:'氯丙嗪与解热镇痛药',symbol:'flame',color:'#efcf95',lead:'观察体温变化时，先区分发热时的调定点上移与体温调节能力本身的改变。',pairs:[
    ['18.2.2','氯丙嗪抑制体温调节功能，体温更容易随环境温度改变。'],
    ['20.1.2','解热镇痛药减少中枢前列腺素生成，使发热时升高的体温调定点回落。']]}
];
function shelf() {
  return `<section class="shelf" aria-labelledby="shelf-title"><div class="section-line"><h2 id="shelf-title">跨章对照</h2><div class="shelf-arrows"><span>${comparisons.length} 组机制联系</span><button class="icon-button" data-shelf="-1" aria-label="向左浏览对照主题">${icon('prev')}</button><button class="icon-button" data-shelf="1" aria-label="向右浏览对照主题">${icon('next')}</button></div></div><div class="shelf-track">${comparisons.map(item=>`<button class="quick-card" data-compare="${item.id}" style="--a:${item.color}">${mark(item.symbol)}<span class="quick-copy"><span class="tile-ch">CH. ${item.pairs.map(([key])=>topics.get(key).c.id).join(' × ')}</span><strong>${esc(item.title)}</strong><small>${esc(item.caption)}</small></span>${icon('next')}</button>`).join('')}</div></section>`;
}
function syncShelf() {
  const shelf=$('.shelf-track');if(!shelf)return;
  const update=()=>{
    const offset=shelf.scrollLeft;
    $('[data-shelf="-1"]').disabled=offset<2;
    $('[data-shelf="1"]').disabled=offset+shelf.clientWidth>=shelf.scrollWidth-2;
  };
  shelf.addEventListener('scroll',update,{passive:true});update();
}
function comparisonCard(item) {
  return `<div class="dialog-wrap compare-wrap" style="--a:${item.color}"><div class="dialog-top"><div class="section-label">${icon('branch')}跨章对照</div>${dialogClose()}</div>
    <div class="detail-kicker">${mark(item.symbol,21)}<span>${esc(item.caption)}</span></div><h2 id="dialog-title" tabindex="-1">${esc(item.title)}</h2><p class="lead">${esc(item.lead)}</p>
    <div class="compare-grid">${item.pairs.map(([key,explain])=>{const {c,t}=topics.get(key);return `<article style="--a:${c.color}"><div class="tile-ch">第 ${c.id} 章</div><h3>${esc(t.title)}</h3><p>${esc(explain)}</p><button class="text-link" data-topic="${key}">深入学习 ${icon('arrow',14)}</button></article>`;}).join('')}</div></div>`;
}


function breadcrumb(c,b) {
  const home=c?'<a href="#/map">全局图谱</a>':'<b>全局图谱</b>';
  const sep=icon('next').replace('class="icon"','class="icon sep"');
  return `<nav class="crumbs" aria-label="导图路径"><span>${icon('orbit')}</span>${home}${c?sep+(b?`<a href="#${chapterPath(c)}">第 ${c.id} 章</a>`:`<b>第 ${c.id} 章 · ${esc(c.short)}</b>`):''}${b?sep+'<b>'+esc(b.title)+'</b>':''}</nav>`;
}
function graphPage(c,b) {
  const count=c?(b?b.topics.length+' 个知识点':c.branches.length+' 个分支'):'7 个章节';
  return intro('药理知识图谱','点选章节，沿着知识分支探索作用机制、代表药物与临床要点。')+
    `<div class="workbench"><section class="panel map-panel" aria-label="交互式思维导图"><div class="map-bar">${breadcrumb(c,b)}<span class="map-count"><i></i>${count}</span></div>
    <div class="map-viewport" id="viewport" tabindex="0" aria-label="导图画布，可用方向键平移，加减键缩放，0 键复位"><div class="map-scene" id="scene"></div></div>
    <div class="map-footer"><div class="canvas-hint">${icon('hand')}<span class="mouse-hint">拖动平移 · 滚轮缩放</span><span class="touch-hint">点按节点展开</span></div>
    <div class="map-tools" aria-label="画布工具"><div class="zoom-group optical"><button class="tool" title="缩小" aria-label="缩小导图" data-action="zoom-out">${icon('minus')}</button><span class="zoom-readout" id="zoom-level">100%</span><button class="tool" title="放大" aria-label="放大导图" data-action="zoom-in">${icon('plus')}</button></div><button class="tool fit-tool optical" title="适应画布" aria-label="适应画布" data-action="fit">${icon('fit')}</button></div></div></section>
    <aside class="panel inspector" id="inspector" aria-label="当前章节导读"></aside></div>`+shelf();
}
function branchRows(c,b) {
  return b?b.topics.map(t=>`<button class="branch-row" data-topic="${t.id}"><i></i><span>${esc(t.title)}</span>${icon(study.done.has(t.id)?'circlecheck':'next')}</button>`).join(''):
    c.branches.map(x=>`<a class="branch-row" href="#${chapterPath(c,x)}"><i></i><span>${esc(x.title)}</span>${icon('next')}</a>`).join('');
}
function showInspector(c,b,inChapter) {
  const box=$('#inspector');
  if (!box) return;
  const title=b?b.title:c.title;
  box.style.setProperty('--a',c.color);
  const cta=b?`<button class="primary" data-topic="${b.topics[0].id}">阅读首个知识点 ${icon('arrow')}</button>`:
    inChapter?`<button class="primary" data-source="${c.id}" data-page="1">浏览本章课件 ${icon('bookopen')}</button>`:
    `<a class="primary" href="#${chapterPath(c)}">展开本章导图 ${icon('arrow')}</a>`;
  box.innerHTML=`<div class="section-label">${icon(b?'branch':'focus')}${b?'分支导读':inChapter?'章节导读':'章节聚焦'}</div>
  <div class="peek-title">${mark(c.icon,26)}<span class="overline">CHAPTER ${c.id}${b?' / 分支 '+b.n:''}</span><h2>${esc(title)}</h2><p>${esc(b?b.summary:c.summary)}</p></div>
  <div class="branch-list"><div class="branch-head"><span>${b?'知识点':'知识分支'}</span><span>${b?b.topics.length+' 个知识点':c.branches.length+' 个分支'}</span></div>${branchRows(c,b)}</div>${cta}`;
}
function catalogPage() {
  return intro('章节目录',`按课件顺序浏览 ${chapters.size} 章、${numberOfPages} 页内容，展开目录可直接进入知识点。`)+
    '<section class="catalog-grid" aria-label="课程章节">'+CURRICULUM.map(c=>`<article class="catalog-card panel" style="--a:${c.color}">
    <div class="catalog-card-head">${mark(c.icon)}<span class="catalog-nums">CHAPTER ${c.id}</span></div><h2><a href="#${chapterPath(c)}">${esc(c.title)}</a></h2><p>${esc(c.summary)}</p>
    <div class="card-meta"><span>${icon('branch')}${c.branches.length} 个分支</span><span>${icon('layers')}${c.size} 个知识点</span><span>${icon('page')}${c.pageCount} 页</span></div>
    <div class="catalog-tools"><button data-outline="${c.id}" aria-expanded="false" aria-controls="outline-${c.id}">${icon('list')} 展开目录</button><a href="#${chapterPath(c)}">进入导图 ${icon('arrow')}</a></div>
    <div id="outline-${c.id}" class="outline-list" hidden>${c.branches.map(b=>`<details><summary>${esc(b.title)} · ${b.topics.length}</summary>${b.topics.map(t=>`<button data-topic="${t.id}">${esc(t.title)}</button>`).join('')}</details>`).join('')}</div></article>`).join('')+'</section>';
}
function savedPage() {
  const keys=[...study.saved].reverse();
  let body=`<div class="empty-state panel">${mark('bookmark',26)}<h2>还没有收藏的知识点</h2><p>打开知识卡片，点按「收藏」，即可在这里集中复习。</p><a class="primary" href="#/map">浏览知识图谱 ${icon('arrow')}</a></div>`;
  if (keys.length) body='<div class="saved-grid">'+keys.map(key=>{
    const {c,b,t}=topics.get(key);
    return `<article class="saved-card panel" style="--a:${c.color}"><button class="saved-open" data-topic="${key}"><span class="tile-ch">CH. ${c.id} · ${esc(b.title)}</span><h2>${esc(t.title)}</h2><p>${esc(t.lead)}</p></button><div class="saved-actions"><small>${study.done.has(key)?'已掌握':'待复习'}</small><button class="icon-button filled" data-toggle="saved" data-key="${key}" aria-label="取消收藏 ${esc(t.title)}">${icon('bookmark')}</button></div></article>`;
  }).join('')+'</div>';
  return intro('我的收藏',keys.length?`已收藏 ${keys.length} 个知识点，点开卡片继续复习。`:'收藏与掌握记录保存在当前浏览器。')+body;
}


function graphGeometry(count,compact,rootLevel,shortMap) {
  if (compact) {
    const rows=Math.ceil(count/2),start=rootLevel?(shortMap?.385:.405):.39, end=rows===1?.71:(shortMap?.892:.88);
    const xy=Array.from({length:count},(_,i)=>{
      const evenLast=i===count-1&&count%2===1;
      return [evenLast?.5:(i%2?.755:.245),rows===1?end:start+(end-start)*Math.floor(i/2)/(rows-1)];
    });
    return {root:[.5,rootLevel?(shortMap?.155:.178):.18],xy};
  }
  const layouts={
    2:[[.198,.49],[.802,.49]],
    3:[[.175,.33],[.50,.83],[.825,.33]],
    4:[[.185,.26],[.175,.74],[.815,.26],[.825,.74]],
    5:[[.185,.23],[.168,.62],[.5,.855],[.815,.23],[.832,.62]],
    7:[[.185,.195],[.17,.485],[.192,.785],[.5,.868],[.815,.195],[.83,.485],[.808,.785]]
  };
  return {root:[.5,count%2===1?.405:.47],xy:layouts[count]};
}
function orbitArt(x,y,r,color,compact) {
  const ellipse=(rx,ry,opacity,dash='',angle=0)=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" transform="rotate(${angle} ${x} ${y})" fill="none" stroke="${color}" stroke-opacity="${opacity}" stroke-width=".85" stroke-dasharray="${dash}"/>`;
  let art=ellipse(r*1.21,r*.76,.19,'',-18)+ellipse(r*1.38,r*.88,.22,'2 7',-18)+ellipse(r*1.27,r*.62,.1,'',24);
  if (!compact) {
    for (const [dx,dy,radius] of [[-1.02,-.35,2.1],[1.05,-.55,2],[.91,.39,1.6],[-.72,.79,1.7],[.24,-.87,1.5]]) {
      art+=`<circle cx="${x+dx*r}" cy="${y+dy*r}" r="${radius}" fill="${color}" opacity=".6"/>`;
    }
  }
  return art;
}
function mapItems(c,b) {
  if (!c) return CURRICULUM.map(ch=>({title:ch.short,label:'CH. '+ch.id,color:ch.color,symbol:ch.icon,href:'#'+chapterPath(ch),preview:ch.id}));
  if (!b) return c.branches.map(br=>({title:br.title,label:br.topics.length+' 个知识点',color:c.color,symbol:'branch',href:'#'+chapterPath(c,br)}));
  return b.topics.map(t=>({title:t.title,label:study.done.has(t.id)?'已掌握':'知识点',color:c.color,symbol:study.done.has(t.id)?'circlecheck':'layers',key:t.id}));
}
function drawMap(c,b) {
  const viewport=$('#viewport'), scene=$('#scene');
  if (!viewport || !scene) return;
  const {width:w,height:h}=viewport.getBoundingClientRect();
  if (!w || !h) return;
  const items=mapItems(c,b), compact=w<610;
  viewport.classList.toggle('compact',compact);
  const shortMap=compact&&h<385;
  viewport.classList.toggle('short-map',shortMap);
  const {root,xy}=graphGeometry(items.length,compact,!c,shortMap);
  const [cx,cy]=[root[0]*w,root[1]*h];
  const width=compact?Math.min(w*.438,238):Math.min(220,Math.max(140,w*.22));
  const stem=cy+(c?(compact?48:66):compact?(shortMap?48:65):Math.min(205,Math.max(118,window.innerWidth*.127))/2+24);
  const rootLabel=c?(b?b.title:c.short):'药理学';
  const rootContents=c?`<div class="root-glyph">${icon(b?'branch':c.icon,38)}</div><span class="root-tag">CH. ${c.id}${b?' / 分支 '+b.n:''}</span><strong class="root-text">${esc(rootLabel)}</strong>`:
    `<img class="brain" width="800" height="800" draggable="false" src="${asset('assets/glass-brain.webp')}" alt=""><strong class="root-text">药理学</strong><small class="root-latin">PHARMACOLOGY</small>`;
  let wires=orbitArt(cx,cy-(c?1:5),compact?(c?39:50):Math.min(w*.127,h*.30),c?c.color:'#8eddd7',compact);
  const nodes=[];
  for (const [i,node] of items.entries()) {
    const [nx,ny]=[xy[i][0]*w,xy[i][1]*h];
    let d,ex,ey=ny;
    if (Math.abs(nx-cx)<1) {
      ex=nx;ey=ny-(compact?26:30);
      d=`M ${cx} ${stem} L ${ex} ${ey}`;
    } else {
      const sign=Math.sign(nx-cx);
      ex=nx-sign*(width/2+1);
      if (compact) {
        const elbow=Math.min(14,Math.abs(ex-cx)*.8);
        d=`M ${cx} ${stem} V ${ey-elbow} Q ${cx} ${ey}, ${cx+sign*elbow} ${ey} H ${ex}`;
      } else {
        const sx=cx+sign*w*.05, sy=cy+(ny-cy)*.11;
        d=`M ${sx} ${sy} C ${sx+sign*w*.10} ${sy}, ${ex-sign*w*.065} ${ey}, ${ex} ${ey}`;
      }
    }
    wires+=`<path class="wire-glow" d="${d}" stroke="${node.color}"/><path class="wire" d="${d}" stroke="${node.color}"/><circle class="wire-dot" cx="${ex}" cy="${ey}" r="2.45" stroke="${node.color}" fill="#1c3348"/>`;
    const attr=node.key?`data-topic="${node.key}"`:`href="${node.href}"`;
    const tag=node.key?'button':'a', preview=node.preview===focusedChapter;
    nodes.push(`<${tag} class="node optical${preview?' previewed':''}" ${attr} ${node.preview?'data-preview="'+node.preview+'"':''} style="left:${xy[i][0]*100}%;top:${xy[i][1]*100}%;width:${width}px;--a:${node.color}" aria-label="${esc(node.title)}，${node.key?'阅读知识点':'展开导图'}">${mark(node.symbol)}<span class="node-body"><small>${esc(node.label)}</small><strong>${esc(node.title)}</strong></span></${tag}>`);
  }
  scene.innerHTML=`<svg class="wires" aria-hidden="true" viewBox="0 0 ${w} ${h}">${wires}</svg><div class="map-root ${c?'deep-root':''}" style="left:${root[0]*100}%;top:${root[1]*100}%;--a:${c?.color||'#8aded1'}">${rootContents}</div>${nodes.join('')}`;
  refreshGlass();
}
function attachMap(route) {
  const el=$('#viewport'),scene=$('#scene');
  const camera=cameras.get(route.base)||{x:0,y:0,z:1};
  cameras.set(route.base,camera);
  function paint() {
    const maxX=el.clientWidth*camera.z*.7, maxY=el.clientHeight*camera.z*.7;
    camera.x=Math.max(-maxX,Math.min(maxX,camera.x));
    camera.y=Math.max(-maxY,Math.min(maxY,camera.y));
    scene.style.transform=`translate(${camera.x}px,${camera.y}px) scale(${camera.z})`;
    $('#zoom-level').textContent=Math.round(camera.z*100)+'%';
    el.classList.toggle('zoomed',camera.z>1.01);
    $('[data-action="zoom-in"]').disabled=camera.z>=2.4;
    $('[data-action="zoom-out"]').disabled=camera.z<=.65;
  }
  function zoom(next,point={x:0,y:0}) {
    next=Math.max(.65,Math.min(2.4,next));
    const factor=next/camera.z;
    camera.x=point.x-(point.x-camera.x)*factor;
    camera.y=point.y-(point.y-camera.y)*factor;
    camera.z=next;paint();
  }
  function fit() {Object.assign(camera,{x:0,y:0,z:1});paint();}
  function localPoint(x,y) {
    const rect=el.getBoundingClientRect();
    return {x:x-rect.left-rect.width/2,y:y-rect.top-rect.height/2};
  }
  graphCamera={step:factor=>zoom(camera.z*factor),fit};
  el.addEventListener('wheel',e=>{
    e.preventDefault();
    zoom(camera.z*Math.exp(-Math.max(-140,Math.min(140,e.deltaY))*.0028),localPoint(e.clientX,e.clientY));
  },{passive:false});
  const pointers=new Map();
  let pan=null,pinch=null,dragged=false;
  function pair() {
    const [a,b]=[...pointers.values()];
    return {distance:Math.hypot(a.x-b.x,a.y-b.y)||1,center:localPoint((a.x+b.x)/2,(a.y+b.y)/2)};
  }
  el.addEventListener('pointerdown',e=>{
    if (e.button!==0) return;
    if (pointers.size===0) dragged=false;
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if (pointers.size===2) {
      const current=pair();
      pinch={...current,x:camera.x,y:camera.y,z:camera.z};pan=null;dragged=true;
      for(const id of pointers.keys()) el.setPointerCapture(id);
    } else if (!e.target.closest('.node')) {
      pan={id:e.pointerId,x:e.clientX,y:e.clientY,startX:camera.x,startY:camera.y};
      el.setPointerCapture(e.pointerId);
    }
  });
  el.addEventListener('pointermove',e=>{
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if (pinch && pointers.size===2) {
      const curr=pair(),z=Math.max(.65,Math.min(2.4,pinch.z*curr.distance/pinch.distance)),f=z/pinch.z;
      camera.x=curr.center.x-(pinch.center.x-pinch.x)*f;camera.y=curr.center.y-(pinch.center.y-pinch.y)*f;camera.z=z;paint();
    } else if (pan?.id===e.pointerId) {
      const dx=e.clientX-pan.x,dy=e.clientY-pan.y;
      if (Math.hypot(dx,dy)>4) dragged=true;
      if (dragged) {camera.x=pan.startX+dx;camera.y=pan.startY+dy;paint();}
    }
  });
  const finish=e=>{pointers.delete(e.pointerId);pan=null;pinch=null;};
  el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);
  el.addEventListener('lostpointercapture',finish);
  el.addEventListener('click',e=>{if(dragged){dragged=false;e.preventDefault();e.stopPropagation();}},true);
  el.addEventListener('keydown',e=>{
    if (e.target!==el) return;
    const offsets={ArrowLeft:[30,0],ArrowRight:[-30,0],ArrowUp:[0,30],ArrowDown:[0,-30]};
    if (offsets[e.key]) {e.preventDefault();const [dx,dy]=offsets[e.key];camera.x+=dx;camera.y+=dy;paint();}
    else if (['+','=','-','0'].includes(e.key)) {e.preventDefault();if(e.key==='0')fit();else zoom(camera.z*(e.key==='-'?1/1.2:1.2));}
  });
  function preview(target) {
    const id=Number(target.closest('[data-preview]')?.dataset.preview);
    if (!id||id===focusedChapter||route.c) return;
    focusedChapter=id;
    scene.querySelectorAll('[data-preview]').forEach(n=>n.classList.toggle('previewed',Number(n.dataset.preview)===id));
    showInspector(chapters.get(id),null,false);
  }
  el.addEventListener('pointerover',e=>{if(e.pointerType==='mouse'&&!pointers.size) preview(e.target);});
  el.addEventListener('focusin',e=>preview(e.target));
  observer=new ResizeObserver(()=>{drawMap(route.c,route.b);paint();});
  observer.observe(el);
  drawMap(route.c,route.b);paint();
}


const dialogClose=()=>`<button class="icon-button" data-action="close" aria-label="关闭" title="关闭">${icon('close',17)}</button>`;
function topicCard({c,b,t}) {
  const bookmarked=study.saved.has(t.id),done=study.done.has(t.id),note=sources[t.title];
  const related=comparisons.find(item=>item.pairs.some(([key])=>key===t.id));
  return `<div class="dialog-wrap" style="--a:${c.color}"><div class="dialog-top"><div class="section-label">${icon('layers')}知识卡片</div>${dialogClose()}</div>
    <div class="detail-body"><div class="detail-kicker">${mark(c.icon,21)}<span>第 ${c.id} 章<span class="kicker-divider">/</span>${esc(b.title)}</span></div>
    <h2 id="dialog-title" tabindex="-1">${esc(t.title)}</h2><p class="lead">${esc(t.lead)}</p>
    <dl class="study-points">${t.points.map(([term,definition])=>`<div><dt>${esc(term)}</dt><dd>${esc(definition)}</dd></div>`).join('')}</dl>
    ${note?`<div class="source-note"><strong>资料核对</strong><p>${esc(note[0])}</p><a href="${esc(note[2])}" target="_blank" rel="noopener noreferrer">${esc(note[1])} ${icon('external',12)}</a></div>`:''}
    ${related?`<button class="cross-link" data-compare="${related.id}">${icon('branch',15)}<span>跨章对照 · ${esc(related.title)}</span>${icon('next',13)}</button>`:''}
    <div class="original-pages"><span>${icon('page',16)} 对照课件原页</span><div>${t.pages.map(p=>`<button data-source="${c.id}" data-page="${p}" aria-label="查看第 ${c.id} 章课件第 ${p} 页">第 ${p} 页 ${icon('next',11)}</button>`).join('')}</div></div></div>
    <div class="detail-actions"><a class="locate" href="#${chapterPath(c,b)}">${icon('focus',16)}<span>在导图中定位</span></a>
    <button class="sub-button ${bookmarked?'filled':''}" data-toggle="saved" data-key="${t.id}" aria-pressed="${bookmarked}">${icon('bookmark')}<span>${bookmarked?'已收藏':'收藏'}</span></button>
    <button class="primary ${done?'is-done':''}" data-toggle="done" data-key="${t.id}" aria-pressed="${done}">${icon(done?'circlecheck':'check')}<span>${done?'已掌握':'标记掌握'}</span></button></div></div>`;
}
function sourceView(c,page) {
  const transcript=c.transcripts[page-1].trim(), desc=transcript.length>8?transcript:`第 ${page} 页以图表或图像呈现。`;
  return `<div class="dialog-wrap source-wrap" style="--a:${c.color}"><div class="dialog-top"><div class="section-label">${icon('page')}课件原页</div>${dialogClose()}</div>
    <div class="source-head"><div><div class="overline">CHAPTER ${c.id}</div><h2 id="dialog-title" tabindex="-1">${esc(c.title)}</h2></div><button class="sub-button image-zoom" data-action="image-zoom" aria-pressed="${slideZoom}" title="切换原页大小">${icon(slideZoom?'minus':'plus')}<span>${slideZoom?'适应窗口':'放大原页'}</span></button></div>
    <div class="paper ${slideZoom?'zoom':''}"><img src="${asset('assets/pages/'+c.id+'/'+page+'.webp')}" alt="第 ${c.id} 章课件第 ${page} 页" aria-describedby="slide-description"><span id="slide-description" class="sr-only">${esc(desc)}</span></div>
    <div class="page-controls"><button class="sub-button" data-flip="-1" ${page===1?'disabled':''}>${icon('prev')} 上一页</button><label><span class="sr-only">跳至页码</span><input id="page-number" type="number" inputmode="numeric" min="1" max="${c.pageCount}" value="${page}" aria-label="跳至页码"> <span>/ ${c.pageCount} 页</span></label><button class="sub-button" data-flip="1" ${page===c.pageCount?'disabled':''}>下一页 ${icon('next')}</button></div></div>`;
}
function searchPanel() {
  return `<div class="dialog-wrap search-wrap"><div class="dialog-top"><div class="section-label">${icon('search')}<h2 id="dialog-title">搜索图谱</h2></div>${dialogClose()}</div>
  <div class="search-field">${icon('search',21)}<input id="study-search" type="search" role="combobox" aria-autocomplete="list" aria-controls="results" aria-expanded="true" aria-label="输入药名、机制或英文缩写" autocomplete="off" placeholder="输入药名、机制或英文缩写" value="${esc(searchValue)}"></div>
  <div id="result-caption" class="result-caption" aria-live="polite"></div><div class="results" id="results" role="listbox" aria-label="搜索结果"></div></div>`;
}
let searchSelected=-1,searchMatches=[];
function showResults() {
  const input=$('#study-search');if(!input)return;
  searchValue=input.value;
  const term=norm(searchValue), words=searchValue.trim().split(/\s+/).map(norm).filter(Boolean);
  if (!term) searchMatches=searchIndex.filter(x=>x.kind==='chapter');
  else {
    const scored=[];
    for (const entry of searchIndex) {
      const title=norm(entry.title);
      if (!words.every(w=>entry.text.includes(w))) continue;
      const score=title===term?100:title.startsWith(term)?80:title.includes(term)?65:entry.alias?.includes(term)?52:entry.text.includes(term)?24:12;
      scored.push({entry,score});
    }
    scored.sort((a,b)=>b.score-a.score);
    searchMatches=scored.map(x=>x.entry);
  }
  searchSelected=-1;input.removeAttribute('aria-activedescendant');
  $('#result-caption').textContent=term?'找到 '+searchMatches.length+' 项结果':'浏览章节';
  $('#results').innerHTML=searchMatches.length?searchMatches.map(({kind,c,b,title},i)=>`<button role="option" aria-selected="false" tabindex="-1" id="match-${i}" data-result="${i}" class="result" style="--a:${c.color}">${mark(kind==='topic'?'layers':kind==='branch'?'branch':c.icon,18)}<span><strong>${esc(title)}</strong><small>第 ${c.id} 章 · ${esc(b?b.title:c.short)} · ${kind==='topic'?'知识点':kind==='branch'?'分支':'章节'}</small></span>${icon('next',15)}</button>`).join(''):'<p class="no-result">没有匹配的知识点。可以试试药物通用名或「钠通道」「COX」等关键词。</p>';
  $('#results').scrollTop=0;
}
function chooseResult(i) {
  const e=searchMatches[i];if(!e)return;
  if(e.kind==='topic') openTopic(e.t.id,true);
  else goto('#'+chapterPath(e.c,e.b),true);
}
function selectResult(step) {
  if (!searchMatches.length) return;
  const prev=$('#match-'+searchSelected);
  prev?.setAttribute('aria-selected','false');
  searchSelected=searchSelected<0?(step>0?0:searchMatches.length-1):(searchSelected+step+searchMatches.length)%searchMatches.length;
  const next=$('#match-'+searchSelected);next.setAttribute('aria-selected','true');
  $('#study-search').setAttribute('aria-activedescendant',next.id);next.scrollIntoView({block:'nearest'});
}
function renderOverlay(route,force=false) {
  const {params}=route, source=chapters.get(Number(params.get('source'))),topic=topics.get(params.get('topic'));
  const page=source?Math.max(1,Math.min(source.pageCount,Number.parseInt(params.get('page'),10)||1)):0;
  const comparison=comparisons.find(x=>x.id===params.get('compare'));
  const type=source?'source':params.has('find')?'search':topic?'topic':comparison?'compare':'';
  const key=type==='source'?source.id+'.'+page:type==='topic'?topic.t.id:type==='compare'?comparison.id:type;
  if(type===dialogType && key===dialogKey&&!force)return;
  const previousType=dialogType;
  dialogType=type;dialogKey=key;
  if(!type) {
    if(dialog.open){dialog.close();document.documentElement.classList.remove('modal-open');}
    dialog.innerHTML='';
    if(dialogTrigger?.isConnected)dialogTrigger.focus({preventScroll:true});
    dialogTrigger=null;return;
  }
  if (!dialog.open) dialogTrigger=document.activeElement;
  if(type==='source'&&previousType!=='source') slideZoom=false;
  if(type==='search'&&previousType!=='search')searchValue='';
  dialog.className='dialog-'+type;
  dialog.innerHTML=type==='source'?sourceView(source,page):type==='topic'?topicCard(topic):type==='compare'?comparisonCard(comparison):searchPanel();
  if(!dialog.open){dialog.showModal();document.documentElement.classList.add('modal-open');}
  dialog.scrollTop=0;
  if(type==='search'){showResults();$('#study-search').focus({preventScroll:true});}
  else $('#dialog-title')?.focus({preventScroll:true});
}
function render() {
  const route=readRoute();
  if (currentBase!==route.base) {
    if(currentBase)positions.set(currentBase,window.scrollY);
    observer?.disconnect();observer=null;graphCamera=null;
    currentBase=route.base;
    main.innerHTML=route.view==='map'?graphPage(route.c,route.b):route.view==='chapters'?catalogPage():savedPage();
    if(route.view==='map'){
      if(route.c)focusedChapter=route.c.id;
      showInspector(route.c||chapters.get(focusedChapter),route.b,!!route.c);attachMap(route);syncShelf();
    }
    document.querySelectorAll('[data-nav]').forEach((a,i)=>{
      const active=a.dataset.nav===route.view;
      if(active){a.setAttribute('aria-current','page');$('.nav-glass').style.setProperty('--nav',i);}
      else a.removeAttribute('aria-current');
    });
    window.scrollTo(0,positions.get(currentBase)||0);
  }
  renderOverlay(route);refreshGlass();
  const title=dialogType==='topic'?topics.get(route.params.get('topic')).t.title:dialogType==='source'?'课件原页':dialogType==='compare'?comparisons.find(x=>x.id===route.params.get('compare')).title:route.view==='chapters'?'章节目录':route.view==='saved'?'我的收藏':route.b?.title||route.c?.short||'药理知识图谱';
  document.title=title+' · NeuroAtlas';
}
function paintStudy(kind,key) {
  const set=study[kind], now=set.has(key),route=readRoute();
  if(route.view==='saved') main.innerHTML=savedPage();
  if($('#progress'))$('#progress').innerHTML=progress();
  if(route.view==='map'&&route.b){drawMap(route.c,route.b);showInspector(route.c,route.b,true);}
  const btn=dialog.querySelector('[data-toggle="'+kind+'"]');
  if(btn){
    btn.setAttribute('aria-pressed',String(now));
    if(kind==='saved'){btn.classList.toggle('filled',now);btn.innerHTML=icon('bookmark')+'<span>'+(now?'已收藏':'收藏')+'</span>';}
    else{btn.classList.toggle('is-done',now);btn.innerHTML=icon(now?'circlecheck':'check')+'<span>'+(now?'已掌握':'标记掌握')+'</span>';}
  }
}
function toggleStudy(kind,key) {
  if(!['saved','done'].includes(kind)||!topics.has(key))return;
  study=readStudyWithSessionFallback();
  const chosen=study[kind];
  chosen.has(key)?chosen.delete(key):chosen.add(key);
  let stored=true;
  try{localStorage.setItem(storageKey,JSON.stringify({saved:[...study.saved],done:[...study.done]}));}
  catch{stored=false;volatileStudy=true;}
  paintStudy(kind,key);
  announce(stored?(kind==='saved'?(chosen.has(key)?'已加入收藏':'已取消收藏'):(chosen.has(key)?'已标记为掌握':'已恢复为待学习')):'本次记录已更新，当前浏览器无法持久保存。');
}
let volatileStudy=false;
function readStudyWithSessionFallback(){return volatileStudy?study:readStudy();}
function turnPage(step) {const {params}=readRoute();goSource(params.get('source'),Number(params.get('page')||1)+step,true);}
function jumpPage() {const input=$('#page-number');if(!input)return;const {params}=readRoute();if(!input.value){input.value=params.get('page')||1;return;}goSource(params.get('source'),input.value,true);}
document.addEventListener('click',e=>{
  const el=e.target.closest?.('button,a');if(!el)return;
  if(e.defaultPrevented||e.altKey||e.metaKey||e.ctrlKey||e.shiftKey)return;
  const d=el.dataset;
  if(el.classList.contains('skip')){e.preventDefault();main.focus();return;}
  if(d.action==='search'){goto(hashWith(readRoute().base,{find:1}));}
  else if(d.action==='close')closeLayer();
  else if(d.action==='fit')graphCamera?.fit();
  else if(d.action==='zoom-in'||d.action==='zoom-out')graphCamera?.step(d.action==='zoom-in'?1.2:1/1.2);
  else if(d.action==='image-zoom'){
    slideZoom=!slideZoom;$('.paper').classList.toggle('zoom',slideZoom);el.setAttribute('aria-pressed',String(slideZoom));
    el.innerHTML=icon(slideZoom?'minus':'plus')+'<span>'+(slideZoom?'适应窗口':'放大原页')+'</span>';
    $('.paper').scrollTo(0,0);
  } else if(d.compare)openLearningLayer({compare:d.compare});
  else if(d.shelf){
    const track=$('.shelf-track');
    track.scrollBy({left:Number(d.shelf)*(track.firstElementChild.offsetWidth+14),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  } else if(d.source)goSource(d.source,d.page);
  else if(d.flip)turnPage(Number(d.flip));
  else if(d.topic)openTopic(d.topic);
  else if(d.toggle)toggleStudy(d.toggle,d.key);
  else if(d.result!==undefined)chooseResult(Number(d.result));
  else if(d.outline){
    const box=$('#outline-'+d.outline);box.hidden=!box.hidden;el.setAttribute('aria-expanded',String(!box.hidden));
    el.innerHTML=icon('list')+(box.hidden?' 展开目录':' 收起目录');
  } else if(el.matches('a[href^="#/"]')){e.preventDefault();goto(el.getAttribute('href'));}
});
document.addEventListener('input',e=>{if(e.target.id==='study-search')showResults();});
document.addEventListener('change',e=>{if(e.target.id==='page-number')jumpPage();});
document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){
    e.preventDefault();if(!dialog.open)goto(hashWith(readRoute().base,{find:1}));else if(dialogType==='search')$('#study-search').focus();
    return;
  }
  if(e.isComposing)return;
  if(e.key==='Escape' && dialog.open){e.preventDefault();closeLayer();return;}
  if(e.target.id==='study-search'){
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();selectResult(e.key==='ArrowDown'?1:-1);}
    if(e.key==='Enter'){e.preventDefault();chooseResult(Math.max(0,searchSelected));}
  }
  if(dialogType==='source'){
    if(e.target.id==='page-number'){if(e.key==='Enter'){e.preventDefault();jumpPage();}return;}
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();const control=dialog.querySelector('[data-flip="'+(e.key==='ArrowLeft'?-1:1)+'"]');if(control&&!control.disabled)control.click();}
  }
});
dialog.addEventListener('cancel',e=>{e.preventDefault();closeLayer();});
dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeLayer();});
window.addEventListener('hashchange',render);
window.addEventListener('popstate',render);
window.addEventListener('storage',e=>{
  if(e.key!==storageKey && e.key!==null)return;study=readStudy();
  const route=readRoute();if(route.view==='saved')main.innerHTML=savedPage();
  if($('#progress'))$('#progress').innerHTML=progress();
  if(route.view==='map'&&route.b){drawMap(route.c,route.b);showInspector(route.c,route.b,true);}
  if(dialogType==='topic')renderOverlay(route,true);
});
document.addEventListener('pointermove',e=>{
  if(e.pointerType!=='mouse')return;const item=e.target.closest('.optical');if(!item)return;
  const r=item.getBoundingClientRect();item.style.setProperty('--light-x',((e.clientX-r.left)/r.width*100)+'%');item.style.setProperty('--light-y',((e.clientY-r.top)/r.height*100)+'%');
},{passive:true});
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});
if(!/Mac|iPhone|iPad/.test(navigator.platform||''))$('.search-launch kbd').textContent='Ctrl K';
render();

