'use strict';
const ICON_PATHS = {
  network:'<circle cx="12" cy="5" r="2.6"/><circle cx="5" cy="18" r="2.6"/><circle cx="19" cy="18" r="2.6"/><path d="m10.8 7.4-4.5 8m7-8 4.5 8M7.8 18h8.4"/>',
  library:'<path d="M3 5.5c3.1-1.1 5.8-.7 9 1.2 3.2-1.9 5.9-2.3 9-1.2v13c-3-.9-5.8-.5-9 1.4-3.1-1.9-6-2.3-9-1.4zM12 7v12"/>',
  bookmark:'<path d="M6.5 4.6A1.6 1.6 0 0 1 8.1 3h7.8a1.6 1.6 0 0 1 1.6 1.6v16l-5.5-3.7-5.5 3.7z"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.3"/><path d="m15.3 15.3 4.5 4.5"/>',
  syringe:'<path d="m14.1 4.2 5.7 5.7M12.1 6.2l5.7 5.7m-2.9-2.8 2.8-2.9m-4.4 1.4-6.5 6.5a2.5 2.5 0 0 0 0 3.5 2.5 2.5 0 0 0 3.5 0l6.5-6.5m-9.9 6.5-3.8 3.8m6.7-9.8 2 2m-.1-4.1 2 2"/>',
  moon:'<path d="M19.2 14.8A7.7 7.7 0 0 1 9.3 4.1 8.6 8.6 0 1 0 20 15.3z"/><path d="M17.7 3v4m-2-2h4"/>',
  pulse:'<path d="M2 13h4.7l3-8.4 3.6 15 3.3-10.4 2 3.8H22"/>',
  neuron:'<path d="m10 9-4-4m8.6 4 3.1-3.4m-2.6 7.9 5 1.7M9.2 13l-5.6 3m8.5-.6.5 5.4M5.9 5l-.6-2M5.8 5 3 5.4m14.6.5.5-2.5m-.4 2.1 3 .5M4 15.8l-.3 2m15.8-3.1 2.1-1"/><path d="m12 6.8 1.2 2.5 3.1 1.7-2.4 2.5-.6 3.1-3-2.3-2.8-.8 1.3-3.2z"/>',
  mind:'<path d="M9 21v-4.1C6.2 15.4 5 13.4 5 10.4A7.4 7.4 0 0 1 19.6 9l1.4 3h-2v3a2.1 2.1 0 0 1-2.1 2.1h-2V21"/><path d="M9 10.5a2.6 2.6 0 0 1 5-.7c.6 1.6-1.1 2.8-2.7 3.6-1.1-.8-2.1-1.7-2.3-2.9z"/>',
  capsule:'<path d="M5.1 18.9a5.7 5.7 0 0 1 0-8.1l5.7-5.7a5.7 5.7 0 1 1 8.1 8.1l-5.7 5.7a5.7 5.7 0 0 1-8.1 0zM8.6 7.4l8 8"/><path d="M13.2 6.5a2.5 2.5 0 0 1 3.1-.3"/>',
  flame:'<path d="M13.2 2.4c1 4.5-2.8 6.1-2.7 9.1-1.9-1.1-2.2-2.5-2.1-4.1C4.4 10.6 3.2 14.1 5 17.5a7.8 7.8 0 0 0 13.6.4c2.2-3.5 1.4-7.7-1.2-10.7.1 2-1 3.4-2.1 3.9 1-4.4.3-6.4-2.1-8.7z"/><path d="M11 19.7c-1.8-2.1-1.1-3.4.8-5.4.1 1.1.5 1.9 1.5 2.8"/>',
  orbit:'<circle cx="12" cy="12" r="2.2"/><ellipse cx="12" cy="12" rx="10" ry="5" transform="rotate(-35 12 12)"/><path d="M5.5 6.3a9 9 0 0 1 14.6 7.4M18.5 17.8a9 9 0 0 1-14.4-7"/>',
  focus:'<path d="M4 9V6a2 2 0 0 1 2-2h3m6 0h3a2 2 0 0 1 2 2v3m0 6v3a2 2 0 0 1-2 2h-3m-6 0H6a2 2 0 0 1-2-2v-3"/><circle cx="12" cy="12" r="2.5"/>',
  layers:'<path d="m3 8 9-4 9 4-9 4zm0 4.5 9 4 9-4M3 17l9 4 9-4"/>',
  branch:'<circle cx="5" cy="5" r="2"/><circle cx="19" cy="7" r="2"/><circle cx="5" cy="19" r="2"/><path d="M5 7v10m.1-2.5c5.1 0 4.9-7.5 11.9-7.5"/>',
  page:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6m-6 4h5"/>',
  arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>', next:'<path d="m9 5 7 7-7 7"/>', prev:'<path d="m15 5-7 7 7 7"/>',
  minus:'<path d="M5 12h14"/>',plus:'<path d="M5 12h14M12 5v14"/>',
  fit:'<path d="M3.8 9V4h5.1m6.2 0h5.1v5m0 6v5h-5.1m-6.2 0H3.8v-5"/>',
  hand:'<path d="M7 14V8a1.4 1.4 0 0 1 2.8 0v3.3-6.9a1.4 1.4 0 0 1 2.8 0v6.4-5a1.3 1.3 0 1 1 2.6 0v5.4-3.4a1.4 1.4 0 0 1 2.8 0v6.7c0 4.4-2 6.8-5.9 6.8-2.1 0-3.5-1-4.7-2.7l-3.6-5.4a1.5 1.5 0 0 1 2.4-1.7l2 2.7"/>',
  check:'<path d="m4.5 12.5 5 5 10-11"/>',circlecheck:'<circle cx="12" cy="12" r="9"/><path d="m7.8 12.2 2.9 3 5.6-6.1"/>',
  close:'<path d="m6 6 12 12m0-12L6 18"/>',list:'<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6h.1M4 12h.1M4 18h.1" stroke-width="3"/>',
  grid:'<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/>',
  height:'<path d="M5 8V4h4m6 0h4v4M5 16v4h4m6 0h4v-4M8 8h8v8H8z"/>',
  external:'<path d="M13 4h7v7m0-7L10 14M9 6H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3"/>',
  bookopen:'<path d="M4 4h6.2c1 0 1.8.7 1.8 1.7V20c0-1-.8-1.7-1.8-1.7H4zm16 0h-6.2c-1 0-1.8.7-1.8 1.7V20c0-1 .8-1.7 1.8-1.7H20z"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 10.6v5.6m0-9.3v.1"/>',
  chevrons:'<path d="m9 5 6 7-6 7"/>'
};
function icon(name, size=20) {
  return '<svg class="icon" width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(ICON_PATHS[name] || '')+'</svg>';
}
