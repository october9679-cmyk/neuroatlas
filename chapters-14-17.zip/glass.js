'use strict';
const glassNS='http://www.w3.org/2000/svg';
const glassDefs=document.createElementNS(glassNS,'svg');
glassDefs.setAttribute('width','0');
glassDefs.setAttribute('height','0');
glassDefs.setAttribute('aria-hidden','true');
glassDefs.style.cssText='position:absolute;left:0;top:0;pointer-events:none';
document.body.append(glassDefs);
const glassMaps=new Set();
let glassFrame=0;

function glassFilter(width,height,radius) {
  const id='lens-'+width+'-'+height+'-'+radius;
  if(glassMaps.has(id)) return id;
  const canvas=document.createElement('canvas');
  canvas.width=width;canvas.height=height;
  const ctx=canvas.getContext('2d'),pixels=ctx.createImageData(width,height);
  const halfW=width/2,halfH=height/2,band=Math.min(8,radius*.64);
  // The rounded meniscus bends the backdrop near the rim. A neutral centre leaves lettering crisp.
  for(let y=0;y<height;y++) {
    for(let x=0;x<width;x++) {
      const px=x+.5-halfW,py=y+.5-halfH;
      const qx=Math.max(Math.abs(px)-halfW+radius,0),qy=Math.max(Math.abs(py)-halfH+radius,0);
      const normal=Math.hypot(qx,qy),depth=radius-normal;
      const bend=depth>=0 && depth<band && normal?Math.pow(1-depth/band,1.45):0;
      const i=4*(y*width+x);
      pixels.data[i]=128+Math.sign(px)*(normal?qx/normal:0)*bend*118;
      pixels.data[i+1]=128+Math.sign(py)*(normal?qy/normal:0)*bend*118;
      pixels.data[i+2]=128;pixels.data[i+3]=255;
    }
  }
  ctx.putImageData(pixels,0,0);
  const filter=document.createElementNS(glassNS,'filter');
  filter.id=id;
  for(const [k,v] of Object.entries({x:'0%',y:'0%',width:'100%',height:'100%','color-interpolation-filters':'sRGB'}))filter.setAttribute(k,v);
  const map=document.createElementNS(glassNS,'feImage');
  map.setAttribute('href',canvas.toDataURL());map.setAttribute('x','0');map.setAttribute('y','0');
  map.setAttribute('width',width);map.setAttribute('height',height);map.setAttribute('preserveAspectRatio','none');map.setAttribute('result','rim');
  const displacement=document.createElementNS(glassNS,'feDisplacementMap');
  for(const [k,v] of Object.entries({in:'SourceGraphic',in2:'rim',scale:'12',xChannelSelector:'R',yChannelSelector:'G'}))displacement.setAttribute(k,v);
  filter.append(map,displacement);glassDefs.append(filter);glassMaps.add(id);
  return id;
}
function refreshGlass() {
  if(glassFrame || matchMedia('(prefers-reduced-transparency: reduce), (prefers-contrast: more)').matches)return;
  glassFrame=requestAnimationFrame(()=>{
    glassFrame=0;
    for(const el of document.querySelectorAll('.nav-glass,.search-launch,.zoom-group,.fit-tool,.node,.progress-pill')) {
      const w=el.clientWidth,h=el.clientHeight;
      if(!w||!h)continue;
      const raw=getComputedStyle(el).borderTopLeftRadius;
      const r=Math.max(1,Math.round(Math.min(h/2,w/2,raw.includes('%')?h/2:parseFloat(raw)||16)));
      el.style.setProperty('--lens','url("#'+glassFilter(w,h,r)+'")');
    }
  });
}
